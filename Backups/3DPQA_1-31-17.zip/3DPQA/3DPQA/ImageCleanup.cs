﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//user Imports
using System.Drawing;
using System.Drawing.Imaging;
using AForge;
using AForge.Imaging;
using AForge.Imaging.Filters;
using AForge.Math.Geometry;


namespace _3DPQA
{
    class ImageCleanup : ImageRegionalization   // Extends ImageRegionalization; ImageIntake
    {
        protected double imgSkew = 0.0;
        protected double imgScale = 1.0; // size percentage of orginal
        private int subThresh = 0;
        private int mapThresh = 0;

#region Constructors

        public ImageCleanup()
            : base() {/* Defalult Constructor */ }

        public ImageCleanup(List<Bitmap> inBmp)
            : base(inBmp)
        {
            // method list for non-parameterized Image Cleanup
            //sharpenImage();
            DerivedDifferences = findDifferences(SubjectImage, BackGround, subThresh);
            DerivedDifferencesSkew = fixSkew(BackGround, DerivedDifferences);
            // fixScale();
            DerivedDifferencesSkew = findDifferences(DerivedDifferencesSkew, ComputerExpected, mapThresh);
        }

        public ImageCleanup(int mapThresh, List<Bitmap> inBmp)
            : base(inBmp)
        {
            this.mapThresh = mapThresh;

            // method list for partially parameterized Image Cleanup
            DerivedDifferences = findDifferences(SubjectImage, BackGround, subThresh);
            DerivedDifferencesSkew = fixSkew(BackGround, DerivedDifferences);
            // fixScale();
            DerivedDifferencesSkew = findDifferences(DerivedDifferencesSkew, ComputerExpected, mapThresh);
        }

        public ImageCleanup(int subThresh, int mapThresh, List<Bitmap> inBmp)
            : base(inBmp)
        {
            this.subThresh = subThresh;
            this.mapThresh = mapThresh;

            // method list for partially parameterized Image Cleanup
            DerivedDifferences = findDifferences(SubjectImage, BackGround, subThresh);
            DerivedDifferencesSkew = fixSkew(BackGround, DerivedDifferences);
            // fixScale();
            DerivedDifferencesSkew = findDifferences(DerivedDifferencesSkew, ComputerExpected, mapThresh);
        }

        public ImageCleanup(int subThresh, int mapThresh, String inExRect, List<Bitmap> inBmp)
            : base(inExRect, inBmp)
        {
            this.subThresh = subThresh;
            this.mapThresh = mapThresh;

            // method list for partially parameterized Image Cleanup
            //sharpenImage();
            DerivedDifferences = findDifferences(SubjectImage, BackGround, subThresh);
            DerivedDifferencesSkew = fixSkew(BackGround, DerivedDifferences);
            // fixScale();
            ComputerExpected = excludeDrawRects(ComputerExpected); // draw exclusion rects on computer expected
            DerivedDifferencesSkew = excludeDrawRects(DerivedDifferencesSkew); // draw exclusion rects on skew diffmap
            DerivedDifferencesSkew = findDifferences(DerivedDifferencesSkew, ComputerExpected, mapThresh);
        }

        public ImageCleanup(int subThresh, int mapThresh, List<RectangleF> inExRect, List<Bitmap> inBmp)
            : base(inExRect, inBmp)
        {
            this.subThresh = subThresh;
            this.mapThresh = mapThresh;

            // method list for partially parameterized Image Cleanup
            //sharpenImage();
            DerivedDifferences = findDifferences(SubjectImage, BackGround, subThresh);
            DerivedDifferencesSkew = fixSkew(BackGround, DerivedDifferences);
            // fixScale();
            ComputerExpected = excludeDrawRects(ComputerExpected); // draw exclusion rects on computer expected
            DerivedDifferencesSkew = excludeDrawRects(DerivedDifferencesSkew); // draw exclusion rects on skew diffmap
            DerivedDifferencesSkew = findDifferences(DerivedDifferencesSkew, ComputerExpected, mapThresh);
        }

        public ImageCleanup(double imgSkew, double imgScale, int mapThresh, List<Bitmap> inBmp)
            : base(inBmp)
        {
            this.imgSkew = imgSkew;
            this.imgScale = imgScale;
            this.mapThresh = mapThresh;

            // method list for fully parameterized Image Cleanup
            //sharpenImage();
            DerivedDifferences = findDifferences(SubjectImage, BackGround, subThresh);
            DerivedDifferencesSkew = fixSkew(imgSkew, DerivedDifferences);
            // fixScale(known scale);
            ComputerExpected = excludeDrawRects(ComputerExpected);
            DerivedDifferencesSkew = excludeDrawRects(DerivedDifferencesSkew); // draw exclusion rects on computer expected
            DerivedDifferencesSkew = findDifferences(DerivedDifferencesSkew, ComputerExpected, mapThresh); // draw exclusion rects on skew diffmap
        }

        public ImageCleanup(double imgSkew, double imgScale, int mapThresh, List<RectangleF> inExRect, List<Bitmap> inBmp)
            : base(inExRect, inBmp)
        {
            this.imgSkew = imgSkew;
            this.imgScale = imgScale;
            this.mapThresh = mapThresh;

            // method list for fully parameterized Image Cleanup
            //sharpenImage();
            DerivedDifferences = findDifferences(SubjectImage, BackGround, subThresh);
            DerivedDifferencesSkew = fixSkew(imgSkew, DerivedDifferences);
            // fixScale(known scale);
            ComputerExpected = excludeDrawRects(ComputerExpected);
            DerivedDifferencesSkew = excludeDrawRects(DerivedDifferencesSkew); // draw exclusion rects on computer expected
            DerivedDifferencesSkew = findDifferences(DerivedDifferencesSkew, ComputerExpected, mapThresh); // draw exclusion rects on skew diffmap
        }

        public ImageCleanup(double imgSkew, double imgScale, int subThresh, int mapThresh, List<RectangleF> inExRect, List<Bitmap> inBmp)
            : base(inExRect, inBmp)
        {
            this.imgSkew = imgSkew;
            this.imgScale = imgScale;
            this.subThresh = subThresh;
            this.mapThresh = mapThresh;

            // method list for fully parameterized Image Cleanup
            //sharpenImage();
            DerivedDifferences = findDifferences(SubjectImage, BackGround, subThresh);
            DerivedDifferencesSkew = fixSkew(imgSkew, DerivedDifferences);     
            // fixScale(known scale);
            ComputerExpected = excludeDrawRects(ComputerExpected);
            DerivedDifferencesSkew = excludeDrawRects(DerivedDifferencesSkew); // draw exclusion rects on computer expected
            DerivedDifferencesSkew = findDifferences(DerivedDifferencesSkew, ComputerExpected, mapThresh); // draw exclusion rects on skew diffmap
        }

#endregion

#region Setters/Getters

        public int getMapThresh()
        {
            return mapThresh;
        }

        public void setMapThresh(int mapThresh)
        {
            this.mapThresh = mapThresh;
        }

        public int getSubThresh()
        {
            return subThresh;
        }

        public void setSubThresh(int subThresh)
        {
            this.subThresh = subThresh;
        }

        public double getSkew()
        {
            return imgSkew;
        }

        public void setSkew(double imgSkew)
        {
            this.imgSkew = imgSkew;
        }

        public double getScale()
        {
            return imgScale;
        }

        public void setScale(double imgScale)
        {
            this.imgScale = imgScale;
        }

#endregion

#region Do_Work

        public void sharpenImage() 
        {
            Sharpen shFilter = new Sharpen();
            shFilter.ApplyInPlace(SubjectImage);
            shFilter.ApplyInPlace(BackGround);
        }  // basic sharpening filter
        
        public Bitmap findDifferences(Bitmap image1, Bitmap image2, int likenessThreshold) 
        {
            Size s1 = image1.Size;
            Size s2 = image2.Size;
            if (s1 != s2) return null;

            Bitmap temp = new Bitmap(s1.Width, s1.Height);

            // create and apply filter
            ThresholdedDifference filter = new ThresholdedDifference(likenessThreshold);
            filter.OverlayImage = image1;
            temp = filter.Apply(image2);

            return temp;
        } // returns B&W Bitmap

        public Bitmap fixSkew(Bitmap toGetSkewFrom, Bitmap toAjdust) 
        {
            Rectangle rec = new Rectangle(0, 0, toGetSkewFrom.Width, toGetSkewFrom.Height);
            BitmapData bitmapdata = toGetSkewFrom.LockBits(rec, ImageLockMode.ReadWrite, PixelFormat.Format8bppIndexed);
            BitmapData bitmapdataout = toAjdust.LockBits(rec, ImageLockMode.ReadWrite, PixelFormat.Format8bppIndexed);

            if (imgSkew == 0.0)
            {
                // create instance of skew checker
                DocumentSkewChecker skewChecker = new DocumentSkewChecker();

                // get documents skew angle
                imgSkew = skewChecker.GetSkewAngle(bitmapdata);
            }
            // create rotation filter
            RotateBilinear rotationFilter = new RotateBilinear(-imgSkew);
            rotationFilter.FillColor = Color.Black;
            // rotate image applying the filter
            Bitmap rotatedImage = rotationFilter.Apply(bitmapdataout);
            toGetSkewFrom.UnlockBits(bitmapdata);
            toAjdust.UnlockBits(bitmapdataout);
            return rotatedImage;
        } // fix skew with unknown skew angle

        public Bitmap fixSkew(double inSkew, Bitmap toAdjust) 
        {
            Rectangle rec = new Rectangle(0, 0, toAdjust.Width, toAdjust.Height);
            BitmapData bitmapdataout = toAdjust.LockBits(rec, ImageLockMode.ReadWrite, PixelFormat.Format8bppIndexed);
            // create rotation filter
            RotateBilinear rotationFilter = new RotateBilinear(-imgSkew);
            rotationFilter.FillColor = Color.Black;
            // rotate image applying the filter
            Bitmap rotatedImage = rotationFilter.Apply(bitmapdataout);
            toAdjust.UnlockBits(bitmapdataout);
            return rotatedImage;
        } // fix skew with a known skew angle

        public Bitmap fixScale(double inScale, Bitmap toAdjust)
        {
            Bitmap temp = new Bitmap(toAdjust);
            return temp;
            // scale based on imageSkew
        } // adjust scale wwith a known scale difference

#endregion

    }
}
