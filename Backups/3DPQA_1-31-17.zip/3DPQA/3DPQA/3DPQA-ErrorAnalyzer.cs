﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
// user Imports
using System.IO;
using System.Drawing.Imaging;

namespace _3DPQA
{
    public partial class _3DPQA_ErrorAnalyzer : Form
    {
        int errIndex = 0;
        AnomalyEvaluator anomEval = null;
        Hough_Process_Steps formErrHPs = new Hough_Process_Steps();

#region Constructors
        public _3DPQA_ErrorAnalyzer()
        {
            InitializeComponent();
        }

        public _3DPQA_ErrorAnalyzer(object a)
        {
            InitializeComponent();
            if (a is AnomalyEvaluator)
            anomEval = (AnomalyEvaluator) a;
        }
#endregion

#region Form_Events

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (anomEval.getErr().Count > 0 && anomEval.getErr() != null)
            {

                if (anomEval is MonoLineFilter)
                {
                    if (anomEval.getErr().Count > 0 && anomEval.getErr().Count > 0)
                    {
                        errIndex++;
                        if (errIndex == anomEval.getErr().Count)
                            errIndex = 0;
                        picErr.Image = anomEval.getErr().ElementAt(errIndex);
                        picFilter.Image = anomEval.getClean().ElementAt(errIndex);
                    }
                }
                else if (anomEval is HoughLine_Transformation)
                { 
                    if (anomEval.getErr().Count > 0 && anomEval.getErr().Count > 0)
                    {
                        errIndex++;
                        if (errIndex == anomEval.getErr().Count)
                            errIndex = 0;
                        picErr.Image = anomEval.getErr().ElementAt(errIndex);
                        picFilter.Image = anomEval.getLineP().ElementAt(errIndex);     
                        lblFiltered.Text = "Hough Space Graph   " + anomEval.getLineP().ElementAt(errIndex).Size;

                        formErrHPs.setImages(anomEval.getEdge().ElementAt(errIndex), anomEval.getSkel().ElementAt(errIndex));
                    }
                }

                lblCurrObj.Text = "Current Error:    " + (errIndex + 1) + "/" + anomEval.getErr().Count;
            } // cycle forward in error list
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            if (anomEval is MonoLineFilter)
            {
                if (anomEval.getErr().Count > 0 && anomEval.getErr().Count > 0)
                {
                    errIndex--;
                    if (errIndex == -1)
                        errIndex = anomEval.getErr().Count - 1;
                    picErr.Image = anomEval.getErr().ElementAt(errIndex);
                    picFilter.Image = anomEval.getClean().ElementAt(errIndex);
                }
            }
            else if (anomEval is HoughLine_Transformation)
            {
                if (anomEval.getErr().Count > 0 && anomEval.getErr().Count > 0)
                {
                    errIndex--;
                    if (errIndex == -1)
                        errIndex = anomEval.getErr().Count - 1;
                    picErr.Image = anomEval.getErr().ElementAt(errIndex);
                    picFilter.Image = anomEval.getLineP().ElementAt(errIndex);
                    lblFiltered.Text = "Hough Space Graph   " + anomEval.getLine().ElementAt(errIndex).Size;

                    formErrHPs.setImages(anomEval.getEdge().ElementAt(errIndex), anomEval.getSkel().ElementAt(errIndex));
                }
            }

            lblCurrObj.Text = "Current Error:    " + (errIndex + 1) + "/" + anomEval.getErr().Count;
        } // cycle back in error list 

        private void _3DPQA_ErrorAnalyzer_Load(object sender, EventArgs e)
        {
            if (anomEval.getErr().Count <= 1)
            {
                btnNext.Enabled = false;
                btnPrev.Enabled = false;
            }

            if (anomEval is MonoLineFilter)
            {
                lblFiltered.Text = "Morphology Filter Applied";

                if (anomEval.getClean().Count > 0 && anomEval.getClean().Count > 0)
                {
                    picErr.Image = anomEval.getErr().ElementAt(0);
                    picFilter.Image = anomEval.getClean().ElementAt(0);
                }
            }
            else if (anomEval is HoughLine_Transformation)
            {
                lblFiltered.Text = "Hough Space Graph   " + anomEval.getLineP().ElementAt(0).Size;
                if (anomEval.getLine().Count > 0 && anomEval.getLine().Count > 0)
                {
                    picErr.Image = anomEval.getErr().ElementAt(0);
                    picFilter.Image = anomEval.getLineP().ElementAt(0);
                }
            }// display number of objects

            lblCurrObj.Text = "Current Error:    " + (errIndex + 1) + "/" + anomEval.getErr().Count;
        }

#endregion

#region Form_Objects

        private void saveCurrentImageToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void processingStepsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formErrHPs.setImages(anomEval.getEdge().ElementAt(errIndex), anomEval.getSkel().ElementAt(errIndex));
            formErrHPs.ShowDialog();
        } 

#endregion
    }
}
