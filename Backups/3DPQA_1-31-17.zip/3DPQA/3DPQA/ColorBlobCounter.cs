﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// user Imports
using System.Drawing;
using System.Drawing.Imaging;
using AForge;
using AForge.Imaging;
using AForge.Imaging.Filters;
using AForge.Math.Geometry;

namespace _3DPQA
{
    class ColorBlobCounter : ImageBlobCounter  // Extends ImageBlobCounter; ImageCleanup; ImageRegionalization; ImageIntake
    {

        private List<Color> backGroundThresh = new List<Color>(); // contins the two 'bounding' colors (changed to private (UML))
        //private List<Blob> imageBlob = new List<Blob>();
        //private List<Rectangle> imageRect = new List<Rectangle>();
        private Size minBlobSize = new Size(30, 30);

        // create blobcounter
        //BlobCounter blobCounter = new BlobCounter();

#region Constructors

        public ColorBlobCounter() :base() {/* Default Constructor*/}

        public ColorBlobCounter(List<Color> backGroundThresh, List<Bitmap> inBmp)
            : base (inBmp)
        {
            this.backGroundThresh = backGroundThresh;
            DerivedDifferences = clearBG(backGroundThresh);
        }

        public ColorBlobCounter(List<Color> backGroundThresh, int mapThresh, List<Bitmap> inBmp)
            : base(mapThresh, inBmp)
        {
            this.backGroundThresh = backGroundThresh;
            DerivedDifferences = clearBG(backGroundThresh);
        }

        public ColorBlobCounter(Size minSize, List<Color> backGroundThresh, double inSkew, double inScale, int mapThresh, List<Bitmap> inBmp)
            : base(inSkew, inScale, mapThresh, inBmp)
        {
            this.backGroundThresh = backGroundThresh;
            DerivedDifferences = clearBG(backGroundThresh);
        }

        public ColorBlobCounter(Size minSize, double inSkew, double inScale, List<Color> backGroundThresh, int mapThresh, List<RectangleF> inExRect, List<Bitmap> inBmp)
            : base(inSkew, inScale, mapThresh, inExRect, inBmp)
        {
            this.backGroundThresh = backGroundThresh;
            DerivedDifferences = clearBG(backGroundThresh);
        }

#endregion

#region Setters/Getters

        public List<Color> getThreshColor()
        {
            return backGroundThresh;
        } // returns array of thresholding colors

        public override String toString()
        {
            String temp = base.toString() + "RGB Color Thresholds: " +
                getThreshColor().ElementAt(0).ToString() + System.Environment.NewLine + 
                getThreshColor().ElementAt(1).ToString() + System.Environment.NewLine + 
                "Blob Minimums: " + "X=" + minBlobSize.Width + ", Y=" + minBlobSize.Height + 
                System.Environment.NewLine;

            for (int i = 0; i < imageRect.Count; i++)
            {
                temp = temp + imageRect[i] + System.Environment.NewLine + "\tFullness: " + imageBlob[i].Fullness + System.Environment.NewLine;
            }
            return temp;
        } // returns base toString and ColorBlobCounter info

#endregion

#region Do_Work

        public Bitmap clearBG(List<Color> backGroundThresh)
        {
            Bitmap temp = new Bitmap (SubjectImage);

            // create filter
            ColorFiltering filter = new ColorFiltering( );

            // set color ranges to keep
            filter.Red   = new IntRange( backGroundThresh.ElementAt(0).R, backGroundThresh.ElementAt(1).R);
            filter.Green = new IntRange( backGroundThresh.ElementAt(0).G, backGroundThresh.ElementAt(1).G);
            filter.Blue  = new IntRange( backGroundThresh.ElementAt(0).B, backGroundThresh.ElementAt(1).B);

            // apply the filter
            filter.ApplyInPlace( temp );
            return temp;
        } // keeps the colors within the RGB ranges of backGroundThresh (color exclusion)

#endregion
    }
}
