﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Text.RegularExpressions;


namespace _3DPQA
{
    class ImageRegionalization : ImageIntake    // Extends ImageIntake
    {
        private List<RectangleF> exclusionRects = new List<RectangleF>(); // changed to private when doing UML

#region Constructors
        public ImageRegionalization()
            : base() { /* Default Constructor*/ }

        public ImageRegionalization(List<Bitmap> inBmp) 
            : base(inBmp) { /*(none --> pass through)*/ }

        public ImageRegionalization(String exclusionRects, List<Bitmap> inBmp)
            : base(inBmp)
        {
            importExclusionInfo(exclusionRects);
        }

        public ImageRegionalization(List<RectangleF> exclusionRects, List<Bitmap> inBmp)
            : base(inBmp)
        {
            this.exclusionRects = exclusionRects;
        }
#endregion
        public void importExclusionInfo(String filepath) // Imports Exclusion List
        {
            String[] exclusionInfo;
            int i = 0;
            int j = 0;

            exclusionInfo = System.IO.File.ReadAllLines(filepath);

            foreach (String rect in exclusionInfo)
            {
                if (rect.StartsWith("{"))
                {
                    String newString = exclusionInfo[i].Trim(new Char[] { ' ', '{', '}' });
                    string[] digits = Regex.Split(exclusionInfo[i], @"\D+");
                    int[] points = new int[4];
                    int k = 0;

                    foreach (string value in digits)
                    {
                        digits[k] = Regex.Replace(digits[k], @"\D+", "");
                        int number = 0;
                        if (int.TryParse(value, out number))
                            points[k - 1] = number;
                        k++;
                    }
                    exclusionRects.Add(new RectangleF(points[0], points[1], points[2], points[3]));
                    j++;
                }
                i++;
            }
        }

        protected Bitmap excludeDrawRects(Bitmap input) // Draw Exclusions
        {
            Bitmap temp = new Bitmap(input.Width, input.Height);
            Graphics g = Graphics.FromImage(temp);
            g.DrawImage(input, 0, 0);
            SolidBrush blackBrush = new SolidBrush(Color.Black);
            foreach (RectangleF rect in exclusionRects)
                g.FillRectangle(blackBrush, rect);
            return temp;
        }

        public Bitmap[] getExclusionBitmapArray()
        {
            Bitmap[] temp = new Bitmap[3];
            //temp[0] = excludeDrawRects(regionInterm);
            //temp[1] = excludeDrawRects(regionComInterm);
            return temp;
        }
        
    }
}
