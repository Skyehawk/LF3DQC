﻿using System;

namespace _3DPQA
{
    class LineFilterTypes
    {
        public static readonly short[,] vert = new short[3,3] { { -1, -1, -1 }, { 0, 0, 0 }, { 1, 1, 1 } };
        public static readonly short[,] nvert = new short[3, 3] { { 1, 1, 1 }, { 0, 0, 0 }, { -1, -1, -1 } };
        public static readonly short[,] horz = new short[3, 3] { { -1, 0, 1 }, { -1, 0, 1 }, { -1, 0, 1 } };
        public static readonly short[,] nhorz = new short[3, 3] { { 1, 0, -1 }, { 1, 0, -1 }, { 1, 0, -1 } };
        public static readonly short[,] none = new short[3, 3] { { -1, -1, -1 }, { -1, -1, -1 }, { -1, -1, -1 } };
    }
}
