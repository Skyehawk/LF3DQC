﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// user Imports
using System.Drawing;
using System.Drawing.Imaging;
using AForge;
using AForge.Imaging;
using AForge.Imaging.Filters;
using AForge.Math.Geometry;

namespace _3DPQA
{
    class MonoBlobCounter : ImageBlobCounter // Extends ImageBlobCounter; ImageCleanup; ImageRegionalization; ImageIntake
    {

        private Size minBlobSize = new Size(30, 30);

#region Constructors

        public MonoBlobCounter()
            : base() {/* Default Constructor */ }

        public MonoBlobCounter(List<Bitmap> inBmp) 
            : base(inBmp)
        {
            // Method list for non-parameterized Blob Counter
            findImageBlob(minBlobSize);
            getBlobImage();
            drawConvexHull();
            drawBoundingRect();
        }

        public MonoBlobCounter(int subThresh, int mapThresh, List<Bitmap> inBmp)
            : base(subThresh, mapThresh, inBmp)
        {
            findImageBlob(minBlobSize);
            getBlobImage();
            drawConvexHull();
            drawBoundingRect();
        }

        public MonoBlobCounter(int subThresh, int mapThresh, String inExRect, List<Bitmap> inBmp)
            : base(subThresh, mapThresh, inExRect, inBmp)
        {
            findImageBlob(minBlobSize);
            getBlobImage();
            drawConvexHull();
            drawBoundingRect();
        }

        public MonoBlobCounter(Size minSize, double inSkew, double inScale, int subThresh, int mapThresh, List<RectangleF> inExRect, List<Bitmap> inBmp)
            : base(inSkew, inScale, subThresh, mapThresh, inExRect, inBmp)
        {
            if (minSize.Width >=1 && minSize.Height >= 1)
            minBlobSize = minSize;

            findImageBlob(minBlobSize);
            getBlobImage();
            drawConvexHull();
            drawBoundingRect();
        }
#endregion

#region Setters/Getters/Utility

        public Size getMinSize()
        {
            return minBlobSize;
        }

        public override String toString()
        {
            //to get parent toString() value: base.toString();
            String temp = base.toString() + "Initial Threshold: " +
                getSubThresh() + System.Environment.NewLine + "Computer Comparison Threshold: " +
                getMapThresh() + System.Environment.NewLine + "Blob Minimums: " + "X=" +
                minBlobSize.Width + ", Y=" + minBlobSize.Height + System.Environment.NewLine;

            for (int i = 0; i < imageRect.Count; i++)
            {
                temp = temp + imageRect[i] + System.Environment.NewLine + "\tFullness: " + imageBlob[i].Fullness + System.Environment.NewLine;
            }
            return temp;
        } // returns base toString and ColorBlobCounter info

#endregion

#region Do_Work

        public void findImageBlob(Size minBlobSize) // process image for a list of blobs and XY bounding rectangles
        {

            Bitmap temp = DerivedDifferencesSkew;

            // create sharpening filter 
            Sharpen shFilter = new Sharpen();
            shFilter.ApplyInPlace(temp);

            // create and apply blob minimum size filter
            BlobsFiltering sFilter = new BlobsFiltering();
            sFilter.CoupledSizeFiltering = false;
            sFilter.MinWidth = minBlobSize.Width;
            sFilter.MinHeight = minBlobSize.Height;
            sFilter.ApplyInPlace(temp);

            //process image with blobcounter & filter
            blobCounter.ProcessImage(temp);
            imageBlob.AddRange(blobCounter.GetObjectsInformation());
            imageRect.AddRange(blobCounter.GetObjectsRectangles());

        } // blob processing for a background subtraction

#endregion

    }
}
