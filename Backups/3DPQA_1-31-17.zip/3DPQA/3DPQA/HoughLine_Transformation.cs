﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// user imports
using System.Drawing;
using System.Drawing.Imaging;
using AForge;
using AForge.Imaging;
using AForge.Imaging.Filters;
using AForge.Math.Geometry;

namespace _3DPQA
{
    class HoughLine_Transformation : AnomalyEvaluator
    {

#region Constructors

        public HoughLine_Transformation()
            : base() { /* Default Constructor */ }

        public HoughLine_Transformation(List<Bitmap> inErr)
            : base(inErr) 
        {
            genHoughLine(inErr);
        }

#endregion

#region Setters/Getters/Utility
        private List<Bitmap> getErrLine()
        {
            return errLine;
        }
#endregion

#region Do_Work

        private void genHoughLine(List<Bitmap> inBmp)
        {
            foreach (Bitmap currB in inBmp)
            {
                // convert input to 8bppIndexed grayscale
                Rectangle rect = new Rectangle(0,0, (Int32)currB.Size.Width, (Int32)currB.Size.Height);
                Bitmap formattedImage = currB.Clone(rect, PixelFormat.Format8bppIndexed);

#region Cleanup
                
                //apply edge detection and skeletonization
                Bitmap edgeDetect = formattedImage;
                // create edge detection filter
                CannyEdgeDetector efilter = new CannyEdgeDetector(); //canny has not proved to give cleanest results, however the other 3 edge detectors are giving 0 results...
                // apply the filter
                efilter.ApplyInPlace(edgeDetect);
                errEdge.Add(edgeDetect); //keep record of edge detection

                Bitmap skeletized = edgeDetect;
                // create skeletonization filter
                SimpleSkeletonization sfilter = new SimpleSkeletonization( );
                // apply the filter
                sfilter.ApplyInPlace( skeletized );
                errSkel.Add(skeletized); // keep record of skelitized edges
                //skeletized.Save("C:\\Users\\skyes\\Documents\\LF3DQC\\print test\\blobs_test"+"\\skel_" + DateTime.Now.ToString("yyyyMMdd_hhmmss") + ".bmp", ImageFormat.Bmp);
#endregion
               

                HoughLineTransformation lineTransform = new HoughLineTransformation();
                // apply Hough line transformation
                lineTransform.ProcessImage(skeletized);
                Bitmap houghLineImage = lineTransform.ToBitmap();
                // get lines using relative intensity
                HoughLine[] lines = lineTransform.GetLinesByRelativeIntensity(0.5);

                foreach (HoughLine line in lines)
                {
                    // get line's radius and theta values
                    int r = line.Radius;
                    double t = line.Theta;

                    // check if line is in lower part of the image
                    if (r < 0)
                    {
                        t += 180;
                        r = -r;
                    }

                    // convert degrees to radians
                    t = (t / 180) * Math.PI;

                    // get image centers (all coordinate are measured relative
                    // to center)
                    int w2 = formattedImage.Width / 2;
                    int h2 = formattedImage.Height / 2;

                    double x0 = 0, x1 = 0, y0 = 0, y1 = 0;

                    if (line.Theta != 0)
                    {
                        // none-vertical line
                        x0 = -w2; // most left point
                        x1 = w2;  // most right point

                        // calculate corresponding y values
                        y0 = (-Math.Cos(t) * x0 + r) / Math.Sin(t);
                        y1 = (-Math.Cos(t) * x1 + r) / Math.Sin(t);
                    }
                    else
                    {
                        // vertical line
                        x0 = line.Radius;
                        x1 = line.Radius;

                        y0 = h2;
                        y1 = -h2;
                    }

                    BitmapData data = houghLineImage.LockBits(
                    new Rectangle(0, 0, houghLineImage.Width, houghLineImage.Height),
                        ImageLockMode.ReadWrite, houghLineImage.PixelFormat);

                    // draw line on the image
                    Drawing.Line(data,
                        new IntPoint((int)x0 + w2, h2 - (int)y0),
                        new IntPoint((int)x1 + w2, h2 - (int)y1),
                        Color.White);

                }
                // add to processed collection
                errLine.Add(houghLineImage);

                // add converted bitmap
                Bitmap temp = new Bitmap(houghLineImage);
                // create filter
                TransformToPolar filter = new TransformToPolar( );
                filter.OffsetAngle = 0;
                filter.CirlceDepth = 1;
                filter.UseOriginalImageSize = true;
                //filter.NewSize = new Size( 200, 200 );
                // apply the filter
                Bitmap newImage = filter.Apply(temp);
                // add processed image to collection
                errLineP.Add(temp);
            }
        }

#endregion

    }
}
