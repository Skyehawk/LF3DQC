﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// user Imports
using System.Drawing;
using System.Drawing.Imaging;
using AForge;
using AForge.Imaging;
using AForge.Imaging.Filters;
using AForge.Math.Geometry;

namespace _3DPQA
{
    abstract class ImageBlobCounter : ImageCleanup   // Extends ImageCleanup; ImageRegionalization; ImageIntake
    {
        protected List<Blob> imageBlob = new List<Blob>();
        protected List<Rectangle> imageRect = new List<Rectangle>();
        private BitmapData data = null;
        private bool exlusion = false;
        // create blobcounter
        protected BlobCounter blobCounter = new BlobCounter();

#region Constructors

        public ImageBlobCounter()
            : base() {/* Default Constructor */ }

        public ImageBlobCounter(List<Bitmap> inBmp) 
            : base(inBmp)
        {
            // Method list for non-parameterized Blob Counter
            //getBlobImage();
        }

        public ImageBlobCounter(int mapThresh, List<Bitmap> inBmp)
            : base(mapThresh, inBmp)
        {
            //getBlobImage();
        }

        public ImageBlobCounter(int subThresh, int mapThresh, List<Bitmap> inBmp)
            : base(subThresh, mapThresh, inBmp)
        {
            //getBlobImage();
        }

        public ImageBlobCounter(int subThresh, int mapThresh, String inExRect, List<Bitmap> inBmp)
            : base(subThresh, mapThresh, inExRect, inBmp)
        {
            //getBlobImage();
        }

        public ImageBlobCounter(double inSkew, double inScale, int mapThresh, List<Bitmap> inBmp)
            : base(inSkew, inScale, mapThresh, inBmp)
        {
            //getBlobImage();
        }

        public ImageBlobCounter(double inSkew, double inScale, int mapThresh, List<RectangleF> inExRect, List<Bitmap> inBmp)
            : base(inSkew, inScale, mapThresh, inExRect, inBmp)
        {
            exlusion = true;
            //getBlobImage();
        }

        public ImageBlobCounter(double inSkew, double inScale, int subThresh, int mapThresh, List<RectangleF> inExRect, List<Bitmap> inBmp)
            : base(inSkew, inScale, subThresh, mapThresh, inExRect, inBmp)
        {
            exlusion = true;
            //getBlobImage();
        }

#endregion

#region Setters/Getters/Utility

        public List<Blob> getImageBlob()
        {
            return imageBlob;
        } // returns blobs

        public List<Rectangle> getImageRect()
        {
            return imageRect;
        } // returns blob rectangles (faster) Rectangle

        public List<RectangleF> getBoundingRect()
        {
            List<RectangleF> temp = new List<RectangleF>();
            foreach (Rectangle curr in imageRect)
            {
                RectangleF rectanglef = curr;
                temp.Add(curr);
            }

            return temp;
        } // returns blob rectangles RectangleF

        public virtual String toString() // returns base data
        {
            return "Rectangle Info: " + System.Environment.NewLine + "Objects Found: " 
                + imageRect.Count + System.Environment.NewLine + "Exclusion Zones: " + exlusion
                + System.Environment.NewLine + "Image Skew: " + getSkew()
                + System.Environment.NewLine + "Image Scale: " + getScale();
        }

        private PointF[] getPoints(RectangleF rectangle)
        {
            return new PointF[3]
            { 
                new PointF(rectangle.Left, rectangle.Top),
                new PointF(rectangle.Right, rectangle.Top),
                new PointF(rectangle.Left, rectangle.Bottom)
            };
        }

        protected void setImageBlob(List<Blob> imageBlob)
        {
            this.imageBlob = imageBlob;
        }

        protected void setImageRect(List<Rectangle> imageRect)
        {
            this.imageRect = imageRect;
        }

#endregion

#region Do_Work

        public void getBlobImage()
        {
            Bitmap temp = new Bitmap(DerivedDifferencesSkew, DerivedDifferencesSkew.Width, DerivedDifferencesSkew.Height);
            
            blobCounter.ObjectsOrder = ObjectsOrder.Size;
            //blobCounter.ProcessImage(temp);
            if (imageBlob.Count > 0)
            {
                foreach (RectangleF currR in imageRect)
                {
                    Bitmap crop = new Bitmap((Int32)currR.Size.Width, (Int32)currR.Size.Height);
                    
                    Graphics g = Graphics.FromImage(crop);
                    g.DrawImage(temp, 0, 0, currR, GraphicsUnit.Pixel);

                    // add to top level error storage
                    IsolatedError.Add(crop);
                }
            }
        } // creates bitmap containing the blob and puts it in the error stack

        public void drawConvexHull()
        {
            Bitmap temp = new Bitmap(DerivedDifferencesSkew, DerivedDifferencesSkew.Width, DerivedDifferencesSkew.Height);
            
            // create convex hull searching algorithm
            GrahamConvexHull hullFinder = new GrahamConvexHull();

            // lock image to draw on it
            data = temp.LockBits(
                new Rectangle(0, 0, temp.Width, temp.Height),
                    ImageLockMode.ReadWrite, temp.PixelFormat);

            // process each blob to compile a list of convex hull polygons
            foreach (Blob blob in imageBlob)
            {
                List<IntPoint> leftPoints, rightPoints, edgePoints = new List<IntPoint>();

                // get blob's edge points
                blobCounter.GetBlobsLeftAndRightEdges(blob,
                    out leftPoints, out rightPoints);

                edgePoints.AddRange(leftPoints);
                edgePoints.AddRange(rightPoints);

                // blob's convex hull
                List<IntPoint> hull = hullFinder.FindHull(edgePoints);
                Drawing.Polygon(data, hull, Color.Red);
            }
            temp.UnlockBits(data);
            BoundedImage = temp;
        } // convex hull drawing for entire image

        public void drawBoundingRect()
        {
            Bitmap temp = BoundedImage;
            // lock image to draw on it
            data = temp.LockBits(
                new Rectangle(0, 0, temp.Width, temp.Height),
                    ImageLockMode.ReadWrite, temp.PixelFormat);

            foreach (Rectangle rect in imageRect)
            {
                Drawing.Rectangle(data, rect, Color.Red);
            }
            temp.UnlockBits(data);
            BoundedImage = temp;
        } // XY bounding rectangle drawing for entire image

#endregion
    }
}
