﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// user Imports
using System.Drawing;
using System.Drawing.Imaging;
using AForge;
using AForge.Imaging;
using AForge.Imaging.Filters;
using AForge.Math.Geometry;

namespace _3DPQA
{
    class MonoLineFilter : AnomalyEvaluator
    {

#region Constructors

        public MonoLineFilter()
            : base() { /* Default Constructor */ }

        public MonoLineFilter(List<Bitmap> inErr)
            : base(inErr) { /* pass error images thru*/ }

        public MonoLineFilter(List<Bitmap> inErr, short[,] d)
            : base(inErr,d) 
        { 
                findLine(inErr, d);
        }

#endregion

#region Do_Work

        public void findLine(List<Bitmap> inErr, short[,] dir)
        {
            List<Bitmap> temp = inErr;
            foreach (Bitmap currB in temp) // clean up mono lines to specified direction
            {
                Bitmap gsImage = Grayscale.CommonAlgorithms.BT709.Apply((currB));
                AForge.Imaging.Filters.HitAndMiss hFilter = new AForge.Imaging.Filters.HitAndMiss(dir);
                Bitmap hImage = hFilter.Apply(gsImage);
                errClean.Add(hImage);
            }
        }
#endregion

    }
}
