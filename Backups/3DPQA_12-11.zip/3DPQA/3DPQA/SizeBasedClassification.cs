﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using AForge;
using AForge.Imaging;
using AForge.Imaging.Filters;
using AForge.Math.Geometry;

namespace _3DPQA
{
    class SizeBasedClassification
    {
        public SizeBasedClassification()
        {
        }

        public List<String> flagObvious(List<Blob> inBlob, Size inSize, double inFullness)
        {
            List<String> temp = new List<String>();
            for (int i = 0; i < inBlob.Count - 1; i++)
            {
                //if ((inBlob[i].Area >= inSize * inSize) && (inBlob[i].Fullness >= inFullness))
                if (inBlob[i].Fullness * inBlob[i].Area > inFullness * inSize.Height * inSize.Width)
                {
                    temp.Add("#True\t" + inBlob[i].Rectangle);
                }
            }
            return temp;
        }
    }
}
