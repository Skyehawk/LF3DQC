﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// user Imports
using System.Drawing;
using System.Drawing.Imaging;
using AForge;
using AForge.Imaging;
using AForge.Imaging.Filters;
using AForge.Math.Geometry;

namespace _3DPQA
{
    class AnomalyEvaluator
    {
        protected List<Bitmap> inErr = new List<Bitmap>();
        protected List<Bitmap> errClean = new List<Bitmap>();
        protected List<Bitmap> errLine = new List<Bitmap>(); // output of HoughLine Transformation (carteasian)
        protected List<Bitmap> errLineP = new List<Bitmap>();// output of HoughLine Transformataion (polar)
        protected List<Bitmap> errEdge = new List<Bitmap>(); // found edges for HoughLines
        protected List<Bitmap> errSkel = new List<Bitmap>(); // reduced of edges for HoughLines

        protected short[,] dir = LineFilterTypes.none; //only processing using the eight sorrounding pixels ([3,3]) method allows up to [15x15]

#region Constructors
        public AnomalyEvaluator()
            : base() {/* Default Constructor*/ }

        public AnomalyEvaluator( List<Bitmap> inErr)
            : base() 
        {
            this.inErr = inErr;
        }

        public AnomalyEvaluator(List<Bitmap> inErr, short[,] d)
            : base()
        {
            this.inErr = inErr;
            this.dir = d;
        }

#endregion

#region Setters/Getters/Utility

        public List<Bitmap> getErr()
        {
            return inErr;
        }

        public List<Bitmap> getClean()
        {
            return errClean;
        }

        public List<Bitmap> getLine()
        {
            return errLine;
        }

        public List<Bitmap> getLineP()
        {
            return errLineP;
        }

        public List<Bitmap> getEdge()
        {
            return errEdge;
        }

        public List<Bitmap> getSkel()
        {
            return errSkel;
        }
#endregion
    }
}
