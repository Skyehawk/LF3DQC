﻿namespace _3DPQA
{
    partial class Hough_Process_Steps
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEdge = new System.Windows.Forms.Label();
            this.lblSkel = new System.Windows.Forms.Label();
            this.picSkel = new System.Windows.Forms.PictureBox();
            this.picEdge = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picSkel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEdge)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEdge
            // 
            this.lblEdge.AutoSize = true;
            this.lblEdge.Location = new System.Drawing.Point(12, 17);
            this.lblEdge.Name = "lblEdge";
            this.lblEdge.Size = new System.Drawing.Size(299, 32);
            this.lblEdge.TabIndex = 2;
            this.lblEdge.Text = "Canny Edge Detection";
            // 
            // lblSkel
            // 
            this.lblSkel.AutoSize = true;
            this.lblSkel.Location = new System.Drawing.Point(652, 17);
            this.lblSkel.Name = "lblSkel";
            this.lblSkel.Size = new System.Drawing.Size(211, 32);
            this.lblSkel.TabIndex = 3;
            this.lblSkel.Text = "Skeletonization";
            // 
            // picSkel
            // 
            this.picSkel.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picSkel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSkel.Location = new System.Drawing.Point(658, 52);
            this.picSkel.Name = "picSkel";
            this.picSkel.Size = new System.Drawing.Size(640, 480);
            this.picSkel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picSkel.TabIndex = 1;
            this.picSkel.TabStop = false;
            // 
            // picEdge
            // 
            this.picEdge.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picEdge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picEdge.Location = new System.Drawing.Point(12, 52);
            this.picEdge.Name = "picEdge";
            this.picEdge.Size = new System.Drawing.Size(640, 480);
            this.picEdge.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picEdge.TabIndex = 0;
            this.picEdge.TabStop = false;
            // 
            // Hough_Process_Steps
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1313, 546);
            this.Controls.Add(this.lblSkel);
            this.Controls.Add(this.lblEdge);
            this.Controls.Add(this.picSkel);
            this.Controls.Add(this.picEdge);
            this.Name = "Hough_Process_Steps";
            this.Text = "HoughLine Transformation Processing Steps";
            this.Load += new System.EventHandler(this.Hough_Process_Steps_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picSkel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEdge)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picEdge;
        private System.Windows.Forms.PictureBox picSkel;
        private System.Windows.Forms.Label lblEdge;
        private System.Windows.Forms.Label lblSkel;
    }
}