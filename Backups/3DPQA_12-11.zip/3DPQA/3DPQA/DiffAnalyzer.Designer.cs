﻿namespace _3DPQA
{
    partial class DiffAnalyzer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.picSub = new System.Windows.Forms.PictureBox();
            this.picBG = new System.Windows.Forms.PictureBox();
            this.picComExp = new System.Windows.Forms.PictureBox();
            this.grpInputs = new System.Windows.Forms.GroupBox();
            this.btnComExpected = new System.Windows.Forms.Button();
            this.btnBackGround = new System.Windows.Forms.Button();
            this.btnSubject = new System.Windows.Forms.Button();
            this.grpOutputs = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDiffMap2 = new System.Windows.Forms.Label();
            this.lblDiffMap = new System.Windows.Forms.Label();
            this.chkCustomExZone = new System.Windows.Forms.CheckBox();
            this.pnlExclude = new System.Windows.Forms.Panel();
            this.btnLoadExZones = new System.Windows.Forms.Button();
            this.txtExcludeYDist = new System.Windows.Forms.TextBox();
            this.txtExcludeXDist = new System.Windows.Forms.TextBox();
            this.txtExcludeY = new System.Windows.Forms.TextBox();
            this.txtExcludeX = new System.Windows.Forms.TextBox();
            this.lblExcludeYDist = new System.Windows.Forms.Label();
            this.lblExcludeXDist = new System.Windows.Forms.Label();
            this.lblExcludeY = new System.Windows.Forms.Label();
            this.lblExcludeX = new System.Windows.Forms.Label();
            this.txtIdealImgThresh = new System.Windows.Forms.TextBox();
            this.lblIdealThresh = new System.Windows.Forms.Label();
            this.lblBlobMinHei = new System.Windows.Forms.Label();
            this.lblBlobMinWid = new System.Windows.Forms.Label();
            this.txtMinHei = new System.Windows.Forms.TextBox();
            this.txtMinWid = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblThresh = new System.Windows.Forms.Label();
            this.txtThres = new System.Windows.Forms.TextBox();
            this.btnSaveDir = new System.Windows.Forms.Button();
            this.grpBlobDetect = new System.Windows.Forms.GroupBox();
            this.radEdge = new System.Windows.Forms.RadioButton();
            this.radBoth = new System.Windows.Forms.RadioButton();
            this.radMono = new System.Windows.Forms.RadioButton();
            this.radColor = new System.Windows.Forms.RadioButton();
            this.btnCompare = new System.Windows.Forms.Button();
            this.mnuStrip = new System.Windows.Forms.MenuStrip();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSub)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picComExp)).BeginInit();
            this.grpInputs.SuspendLayout();
            this.grpOutputs.SuspendLayout();
            this.pnlExclude.SuspendLayout();
            this.grpBlobDetect.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Location = new System.Drawing.Point(6, 37);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(500, 375);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Location = new System.Drawing.Point(524, 37);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(500, 375);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6.Location = new System.Drawing.Point(1041, 37);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(500, 375);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            // 
            // picSub
            // 
            this.picSub.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picSub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSub.Location = new System.Drawing.Point(6, 37);
            this.picSub.Name = "picSub";
            this.picSub.Size = new System.Drawing.Size(500, 375);
            this.picSub.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picSub.TabIndex = 0;
            this.picSub.TabStop = false;
            // 
            // picBG
            // 
            this.picBG.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picBG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBG.Location = new System.Drawing.Point(524, 37);
            this.picBG.Name = "picBG";
            this.picBG.Size = new System.Drawing.Size(500, 375);
            this.picBG.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBG.TabIndex = 1;
            this.picBG.TabStop = false;
            // 
            // picComExp
            // 
            this.picComExp.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picComExp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picComExp.Location = new System.Drawing.Point(1041, 37);
            this.picComExp.Name = "picComExp";
            this.picComExp.Size = new System.Drawing.Size(500, 375);
            this.picComExp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picComExp.TabIndex = 2;
            this.picComExp.TabStop = false;
            // 
            // grpInputs
            // 
            this.grpInputs.Controls.Add(this.btnComExpected);
            this.grpInputs.Controls.Add(this.btnBackGround);
            this.grpInputs.Controls.Add(this.btnSubject);
            this.grpInputs.Controls.Add(this.picSub);
            this.grpInputs.Controls.Add(this.picComExp);
            this.grpInputs.Controls.Add(this.picBG);
            this.grpInputs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grpInputs.Location = new System.Drawing.Point(12, 66);
            this.grpInputs.Name = "grpInputs";
            this.grpInputs.Padding = new System.Windows.Forms.Padding(5);
            this.grpInputs.Size = new System.Drawing.Size(1547, 490);
            this.grpInputs.TabIndex = 6;
            this.grpInputs.TabStop = false;
            this.grpInputs.Text = "Input Images";
            // 
            // btnComExpected
            // 
            this.btnComExpected.Location = new System.Drawing.Point(1041, 423);
            this.btnComExpected.Name = "btnComExpected";
            this.btnComExpected.Size = new System.Drawing.Size(500, 59);
            this.btnComExpected.TabIndex = 5;
            this.btnComExpected.Text = "Computer Expected Image";
            this.btnComExpected.UseVisualStyleBackColor = true;
            this.btnComExpected.Click += new System.EventHandler(this.btnComExpected_Click);
            // 
            // btnBackGround
            // 
            this.btnBackGround.Location = new System.Drawing.Point(524, 423);
            this.btnBackGround.Name = "btnBackGround";
            this.btnBackGround.Size = new System.Drawing.Size(500, 59);
            this.btnBackGround.TabIndex = 4;
            this.btnBackGround.Text = "Background Image";
            this.btnBackGround.UseVisualStyleBackColor = true;
            this.btnBackGround.Click += new System.EventHandler(this.btnBackGround_Click);
            // 
            // btnSubject
            // 
            this.btnSubject.Location = new System.Drawing.Point(6, 423);
            this.btnSubject.Name = "btnSubject";
            this.btnSubject.Size = new System.Drawing.Size(500, 59);
            this.btnSubject.TabIndex = 3;
            this.btnSubject.Text = "Subject Object Image";
            this.btnSubject.UseVisualStyleBackColor = true;
            this.btnSubject.Click += new System.EventHandler(this.btnSubject_Click);
            // 
            // grpOutputs
            // 
            this.grpOutputs.Controls.Add(this.label1);
            this.grpOutputs.Controls.Add(this.lblDiffMap2);
            this.grpOutputs.Controls.Add(this.lblDiffMap);
            this.grpOutputs.Controls.Add(this.pictureBox6);
            this.grpOutputs.Controls.Add(this.pictureBox5);
            this.grpOutputs.Controls.Add(this.pictureBox4);
            this.grpOutputs.Location = new System.Drawing.Point(12, 562);
            this.grpOutputs.Name = "grpOutputs";
            this.grpOutputs.Size = new System.Drawing.Size(1547, 461);
            this.grpOutputs.TabIndex = 7;
            this.grpOutputs.TabStop = false;
            this.grpOutputs.Text = "Output Images";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1035, 415);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(488, 32);
            this.label1.TabIndex = 8;
            this.label1.Text = "Obj vs. BG vs. Exp (w/ Bounding Box)";
            // 
            // lblDiffMap2
            // 
            this.lblDiffMap2.AutoSize = true;
            this.lblDiffMap2.Location = new System.Drawing.Point(518, 415);
            this.lblDiffMap2.Name = "lblDiffMap2";
            this.lblDiffMap2.Size = new System.Drawing.Size(425, 32);
            this.lblDiffMap2.TabIndex = 7;
            this.lblDiffMap2.Text = "Obj vs. BG vs. Exp (w/ Skew CX)";
            // 
            // lblDiffMap
            // 
            this.lblDiffMap.AutoSize = true;
            this.lblDiffMap.Location = new System.Drawing.Point(6, 415);
            this.lblDiffMap.Name = "lblDiffMap";
            this.lblDiffMap.Size = new System.Drawing.Size(151, 32);
            this.lblDiffMap.TabIndex = 6;
            this.lblDiffMap.Text = "Obj vs. BG";
            // 
            // chkCustomExZone
            // 
            this.chkCustomExZone.AutoSize = true;
            this.chkCustomExZone.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkCustomExZone.Location = new System.Drawing.Point(1597, 302);
            this.chkCustomExZone.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.chkCustomExZone.Name = "chkCustomExZone";
            this.chkCustomExZone.Size = new System.Drawing.Size(367, 36);
            this.chkCustomExZone.TabIndex = 55;
            this.chkCustomExZone.Text = "Custom Exclusion Zone: ";
            this.chkCustomExZone.UseVisualStyleBackColor = true;
            this.chkCustomExZone.CheckedChanged += new System.EventHandler(this.chkCustomExZone_CheckedChanged);
            // 
            // pnlExclude
            // 
            this.pnlExclude.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnlExclude.Controls.Add(this.btnLoadExZones);
            this.pnlExclude.Controls.Add(this.txtExcludeYDist);
            this.pnlExclude.Controls.Add(this.txtExcludeXDist);
            this.pnlExclude.Controls.Add(this.txtExcludeY);
            this.pnlExclude.Controls.Add(this.txtExcludeX);
            this.pnlExclude.Controls.Add(this.lblExcludeYDist);
            this.pnlExclude.Controls.Add(this.lblExcludeXDist);
            this.pnlExclude.Controls.Add(this.lblExcludeY);
            this.pnlExclude.Controls.Add(this.lblExcludeX);
            this.pnlExclude.Location = new System.Drawing.Point(1597, 343);
            this.pnlExclude.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.pnlExclude.Name = "pnlExclude";
            this.pnlExclude.Size = new System.Drawing.Size(371, 283);
            this.pnlExclude.TabIndex = 56;
            // 
            // btnLoadExZones
            // 
            this.btnLoadExZones.Enabled = false;
            this.btnLoadExZones.Location = new System.Drawing.Point(8, 218);
            this.btnLoadExZones.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnLoadExZones.Name = "btnLoadExZones";
            this.btnLoadExZones.Size = new System.Drawing.Size(357, 59);
            this.btnLoadExZones.TabIndex = 68;
            this.btnLoadExZones.Text = "Load Exclusion Zones File";
            this.btnLoadExZones.UseVisualStyleBackColor = true;
            this.btnLoadExZones.Click += new System.EventHandler(this.btnLoadExZones_Click);
            // 
            // txtExcludeYDist
            // 
            this.txtExcludeYDist.AcceptsReturn = true;
            this.txtExcludeYDist.AcceptsTab = true;
            this.txtExcludeYDist.AllowDrop = true;
            this.txtExcludeYDist.Enabled = false;
            this.txtExcludeYDist.Location = new System.Drawing.Point(282, 166);
            this.txtExcludeYDist.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtExcludeYDist.Name = "txtExcludeYDist";
            this.txtExcludeYDist.Size = new System.Drawing.Size(79, 38);
            this.txtExcludeYDist.TabIndex = 15;
            this.txtExcludeYDist.Text = "0";
            this.txtExcludeYDist.TextChanged += new System.EventHandler(this.txtExcludeYDist_TextChanged);
            // 
            // txtExcludeXDist
            // 
            this.txtExcludeXDist.AcceptsReturn = true;
            this.txtExcludeXDist.AcceptsTab = true;
            this.txtExcludeXDist.AllowDrop = true;
            this.txtExcludeXDist.Enabled = false;
            this.txtExcludeXDist.Location = new System.Drawing.Point(282, 111);
            this.txtExcludeXDist.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtExcludeXDist.Name = "txtExcludeXDist";
            this.txtExcludeXDist.Size = new System.Drawing.Size(79, 38);
            this.txtExcludeXDist.TabIndex = 14;
            this.txtExcludeXDist.Text = "0";
            this.txtExcludeXDist.TextChanged += new System.EventHandler(this.txtExcludeXDist_TextChanged);
            // 
            // txtExcludeY
            // 
            this.txtExcludeY.AcceptsReturn = true;
            this.txtExcludeY.AcceptsTab = true;
            this.txtExcludeY.AllowDrop = true;
            this.txtExcludeY.Enabled = false;
            this.txtExcludeY.Location = new System.Drawing.Point(282, 57);
            this.txtExcludeY.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtExcludeY.Name = "txtExcludeY";
            this.txtExcludeY.Size = new System.Drawing.Size(79, 38);
            this.txtExcludeY.TabIndex = 13;
            this.txtExcludeY.Text = "0";
            this.txtExcludeY.TextChanged += new System.EventHandler(this.txtExcludeY_TextChanged);
            // 
            // txtExcludeX
            // 
            this.txtExcludeX.AcceptsReturn = true;
            this.txtExcludeX.AcceptsTab = true;
            this.txtExcludeX.AllowDrop = true;
            this.txtExcludeX.Enabled = false;
            this.txtExcludeX.Location = new System.Drawing.Point(282, 5);
            this.txtExcludeX.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtExcludeX.Name = "txtExcludeX";
            this.txtExcludeX.Size = new System.Drawing.Size(79, 38);
            this.txtExcludeX.TabIndex = 12;
            this.txtExcludeX.Text = "0";
            this.txtExcludeX.TextChanged += new System.EventHandler(this.txtExcludeX_TextChanged);
            // 
            // lblExcludeYDist
            // 
            this.lblExcludeYDist.AutoSize = true;
            this.lblExcludeYDist.Enabled = false;
            this.lblExcludeYDist.Location = new System.Drawing.Point(8, 169);
            this.lblExcludeYDist.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblExcludeYDist.Name = "lblExcludeYDist";
            this.lblExcludeYDist.Size = new System.Drawing.Size(235, 32);
            this.lblExcludeYDist.TabIndex = 43;
            this.lblExcludeYDist.Text = "Exclude Y Pixels:";
            // 
            // lblExcludeXDist
            // 
            this.lblExcludeXDist.AutoSize = true;
            this.lblExcludeXDist.Enabled = false;
            this.lblExcludeXDist.Location = new System.Drawing.Point(8, 117);
            this.lblExcludeXDist.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblExcludeXDist.Name = "lblExcludeXDist";
            this.lblExcludeXDist.Size = new System.Drawing.Size(235, 32);
            this.lblExcludeXDist.TabIndex = 42;
            this.lblExcludeXDist.Text = "Exclude X Pixels:";
            // 
            // lblExcludeY
            // 
            this.lblExcludeY.AutoSize = true;
            this.lblExcludeY.Enabled = false;
            this.lblExcludeY.Location = new System.Drawing.Point(8, 64);
            this.lblExcludeY.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblExcludeY.Name = "lblExcludeY";
            this.lblExcludeY.Size = new System.Drawing.Size(152, 32);
            this.lblExcludeY.TabIndex = 41;
            this.lblExcludeY.Text = "Y Position:";
            // 
            // lblExcludeX
            // 
            this.lblExcludeX.AutoSize = true;
            this.lblExcludeX.Enabled = false;
            this.lblExcludeX.Location = new System.Drawing.Point(8, 12);
            this.lblExcludeX.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblExcludeX.Name = "lblExcludeX";
            this.lblExcludeX.Size = new System.Drawing.Size(152, 32);
            this.lblExcludeX.TabIndex = 40;
            this.lblExcludeX.Text = "X Position:";
            // 
            // txtIdealImgThresh
            // 
            this.txtIdealImgThresh.Location = new System.Drawing.Point(1889, 145);
            this.txtIdealImgThresh.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtIdealImgThresh.Name = "txtIdealImgThresh";
            this.txtIdealImgThresh.Size = new System.Drawing.Size(79, 38);
            this.txtIdealImgThresh.TabIndex = 51;
            this.txtIdealImgThresh.Text = "5";
            this.txtIdealImgThresh.TextChanged += new System.EventHandler(this.txtIdealImgThresh_TextChanged);
            // 
            // lblIdealThresh
            // 
            this.lblIdealThresh.AutoSize = true;
            this.lblIdealThresh.Location = new System.Drawing.Point(1591, 148);
            this.lblIdealThresh.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblIdealThresh.Name = "lblIdealThresh";
            this.lblIdealThresh.Size = new System.Drawing.Size(272, 32);
            this.lblIdealThresh.TabIndex = 66;
            this.lblIdealThresh.Text = "Ideal Img Threshold:";
            // 
            // lblBlobMinHei
            // 
            this.lblBlobMinHei.AutoSize = true;
            this.lblBlobMinHei.Location = new System.Drawing.Point(1591, 253);
            this.lblBlobMinHei.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblBlobMinHei.Name = "lblBlobMinHei";
            this.lblBlobMinHei.Size = new System.Drawing.Size(224, 32);
            this.lblBlobMinHei.TabIndex = 63;
            this.lblBlobMinHei.Text = "Min Blob Height:";
            // 
            // lblBlobMinWid
            // 
            this.lblBlobMinWid.AutoSize = true;
            this.lblBlobMinWid.Location = new System.Drawing.Point(1591, 203);
            this.lblBlobMinWid.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblBlobMinWid.Name = "lblBlobMinWid";
            this.lblBlobMinWid.Size = new System.Drawing.Size(214, 32);
            this.lblBlobMinWid.TabIndex = 62;
            this.lblBlobMinWid.Text = "Min Blob Width:";
            // 
            // txtMinHei
            // 
            this.txtMinHei.Location = new System.Drawing.Point(1889, 250);
            this.txtMinHei.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtMinHei.Name = "txtMinHei";
            this.txtMinHei.Size = new System.Drawing.Size(79, 38);
            this.txtMinHei.TabIndex = 53;
            this.txtMinHei.Text = "5";
            this.txtMinHei.TextChanged += new System.EventHandler(this.txtMinHei_TextChanged);
            // 
            // txtMinWid
            // 
            this.txtMinWid.Location = new System.Drawing.Point(1889, 200);
            this.txtMinWid.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtMinWid.Name = "txtMinWid";
            this.txtMinWid.Size = new System.Drawing.Size(79, 38);
            this.txtMinWid.TabIndex = 52;
            this.txtMinWid.Text = "5";
            this.txtMinWid.TextChanged += new System.EventHandler(this.txtMinWid_TextChanged);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(1597, 963);
            this.btnCalculate.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(371, 59);
            this.btnCalculate.TabIndex = 59;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // lblThresh
            // 
            this.lblThresh.AutoSize = true;
            this.lblThresh.Location = new System.Drawing.Point(1591, 96);
            this.lblThresh.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblThresh.Name = "lblThresh";
            this.lblThresh.Size = new System.Drawing.Size(270, 32);
            this.lblThresh.TabIndex = 61;
            this.lblThresh.Text = "Likeness Threshold:";
            // 
            // txtThres
            // 
            this.txtThres.AcceptsReturn = true;
            this.txtThres.AcceptsTab = true;
            this.txtThres.AllowDrop = true;
            this.txtThres.Location = new System.Drawing.Point(1889, 93);
            this.txtThres.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtThres.Name = "txtThres";
            this.txtThres.Size = new System.Drawing.Size(79, 38);
            this.txtThres.TabIndex = 50;
            this.txtThres.Text = "160";
            this.txtThres.TextChanged += new System.EventHandler(this.txtThres_TextChanged);
            // 
            // btnSaveDir
            // 
            this.btnSaveDir.Location = new System.Drawing.Point(1597, 890);
            this.btnSaveDir.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnSaveDir.Name = "btnSaveDir";
            this.btnSaveDir.Size = new System.Drawing.Size(371, 59);
            this.btnSaveDir.TabIndex = 67;
            this.btnSaveDir.Text = "Select Save Dir.";
            this.btnSaveDir.UseVisualStyleBackColor = true;
            this.btnSaveDir.Click += new System.EventHandler(this.btnSaveDir_Click_1);
            // 
            // grpBlobDetect
            // 
            this.grpBlobDetect.Controls.Add(this.radEdge);
            this.grpBlobDetect.Controls.Add(this.radBoth);
            this.grpBlobDetect.Controls.Add(this.radMono);
            this.grpBlobDetect.Controls.Add(this.radColor);
            this.grpBlobDetect.Location = new System.Drawing.Point(1597, 636);
            this.grpBlobDetect.Name = "grpBlobDetect";
            this.grpBlobDetect.Size = new System.Drawing.Size(370, 173);
            this.grpBlobDetect.TabIndex = 68;
            this.grpBlobDetect.TabStop = false;
            this.grpBlobDetect.Text = "Error Detection";
            // 
            // radEdge
            // 
            this.radEdge.AutoSize = true;
            this.radEdge.Location = new System.Drawing.Point(242, 37);
            this.radEdge.Name = "radEdge";
            this.radEdge.Size = new System.Drawing.Size(119, 36);
            this.radEdge.TabIndex = 3;
            this.radEdge.Text = "Edge";
            this.radEdge.UseVisualStyleBackColor = true;
            // 
            // radBoth
            // 
            this.radBoth.AutoSize = true;
            this.radBoth.Location = new System.Drawing.Point(14, 121);
            this.radBoth.Name = "radBoth";
            this.radBoth.Size = new System.Drawing.Size(192, 36);
            this.radBoth.TabIndex = 2;
            this.radBoth.Text = "RGB/Mono";
            this.radBoth.UseVisualStyleBackColor = true;
            // 
            // radMono
            // 
            this.radMono.AutoSize = true;
            this.radMono.Checked = true;
            this.radMono.Location = new System.Drawing.Point(14, 79);
            this.radMono.Name = "radMono";
            this.radMono.Size = new System.Drawing.Size(123, 36);
            this.radMono.TabIndex = 1;
            this.radMono.TabStop = true;
            this.radMono.Text = "Mono";
            this.radMono.UseVisualStyleBackColor = true;
            // 
            // radColor
            // 
            this.radColor.AutoSize = true;
            this.radColor.Location = new System.Drawing.Point(14, 37);
            this.radColor.Name = "radColor";
            this.radColor.Size = new System.Drawing.Size(113, 36);
            this.radColor.TabIndex = 0;
            this.radColor.Text = "RGB";
            this.radColor.UseVisualStyleBackColor = true;
            // 
            // btnCompare
            // 
            this.btnCompare.Location = new System.Drawing.Point(1597, 819);
            this.btnCompare.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnCompare.Name = "btnCompare";
            this.btnCompare.Size = new System.Drawing.Size(371, 59);
            this.btnCompare.TabIndex = 69;
            this.btnCompare.Text = "Select Comparison Dir.";
            this.btnCompare.UseVisualStyleBackColor = true;
            // 
            // mnuStrip
            // 
            this.mnuStrip.Location = new System.Drawing.Point(0, 0);
            this.mnuStrip.Name = "mnuStrip";
            this.mnuStrip.Size = new System.Drawing.Size(1985, 24);
            this.mnuStrip.TabIndex = 70;
            this.mnuStrip.Text = "menuStrip1";
            // 
            // DiffAnalyzer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1985, 1038);
            this.Controls.Add(this.btnCompare);
            this.Controls.Add(this.grpBlobDetect);
            this.Controls.Add(this.btnSaveDir);
            this.Controls.Add(this.chkCustomExZone);
            this.Controls.Add(this.pnlExclude);
            this.Controls.Add(this.txtIdealImgThresh);
            this.Controls.Add(this.lblIdealThresh);
            this.Controls.Add(this.lblBlobMinHei);
            this.Controls.Add(this.lblBlobMinWid);
            this.Controls.Add(this.txtMinHei);
            this.Controls.Add(this.txtMinWid);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblThresh);
            this.Controls.Add(this.txtThres);
            this.Controls.Add(this.grpOutputs);
            this.Controls.Add(this.grpInputs);
            this.Controls.Add(this.mnuStrip);
            this.MainMenuStrip = this.mnuStrip;
            this.Name = "DiffAnalyzer";
            this.Text = "Print QA";
            this.Load += new System.EventHandler(this.DiffAnalyzer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSub)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picComExp)).EndInit();
            this.grpInputs.ResumeLayout(false);
            this.grpOutputs.ResumeLayout(false);
            this.grpOutputs.PerformLayout();
            this.pnlExclude.ResumeLayout(false);
            this.pnlExclude.PerformLayout();
            this.grpBlobDetect.ResumeLayout(false);
            this.grpBlobDetect.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox picSub;
        private System.Windows.Forms.PictureBox picBG;
        private System.Windows.Forms.PictureBox picComExp;
        private System.Windows.Forms.GroupBox grpInputs;
        private System.Windows.Forms.Button btnSubject;
        private System.Windows.Forms.Button btnComExpected;
        private System.Windows.Forms.Button btnBackGround;
        private System.Windows.Forms.GroupBox grpOutputs;
        private System.Windows.Forms.CheckBox chkCustomExZone;
        private System.Windows.Forms.Panel pnlExclude;
        private System.Windows.Forms.TextBox txtExcludeYDist;
        private System.Windows.Forms.TextBox txtExcludeXDist;
        private System.Windows.Forms.TextBox txtExcludeY;
        private System.Windows.Forms.TextBox txtExcludeX;
        private System.Windows.Forms.Label lblExcludeYDist;
        private System.Windows.Forms.Label lblExcludeXDist;
        private System.Windows.Forms.Label lblExcludeY;
        private System.Windows.Forms.Label lblExcludeX;
        private System.Windows.Forms.TextBox txtIdealImgThresh;
        private System.Windows.Forms.Label lblIdealThresh;
        private System.Windows.Forms.Label lblBlobMinHei;
        private System.Windows.Forms.Label lblBlobMinWid;
        private System.Windows.Forms.TextBox txtMinHei;
        private System.Windows.Forms.TextBox txtMinWid;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblThresh;
        private System.Windows.Forms.TextBox txtThres;
        private System.Windows.Forms.Label lblDiffMap;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDiffMap2;
        private System.Windows.Forms.Button btnSaveDir;
        private System.Windows.Forms.Button btnLoadExZones;
        private System.Windows.Forms.GroupBox grpBlobDetect;
        private System.Windows.Forms.RadioButton radBoth;
        private System.Windows.Forms.RadioButton radMono;
        private System.Windows.Forms.RadioButton radColor;
        private System.Windows.Forms.RadioButton radEdge;
        private System.Windows.Forms.Button btnCompare;
        private System.Windows.Forms.MenuStrip mnuStrip;
    }
}

