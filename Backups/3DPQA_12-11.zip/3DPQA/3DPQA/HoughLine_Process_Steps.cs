﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _3DPQA
{
    public partial class Hough_Process_Steps : Form
    {
        public Hough_Process_Steps()
        {
            InitializeComponent();
        }

        private void Hough_Process_Steps_Load(object sender, EventArgs e)
        {
            
        }

        public void setImages(Bitmap inEdge, Bitmap inSkel)
        {
            picEdge.Image = inEdge;
            picSkel.Image = inSkel;
        }
    }
}
