﻿namespace _3DPQA
{
    partial class _3DPQA_ErrorAnalyzer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrev = new System.Windows.Forms.Button();
            this.lblCurrObj = new System.Windows.Forms.Label();
            this.lblFlagged = new System.Windows.Forms.Label();
            this.lblFiltered = new System.Windows.Forms.Label();
            this.mnuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveImageSetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveCurrentImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.processingStepsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aNNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aNNTrainerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.replaceCurrentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.replaceDatasetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.commitDatasetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeCurrentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.killDatasetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.nameDatasetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.picFilter = new System.Windows.Forms.PictureBox();
            this.picErr = new System.Windows.Forms.PictureBox();
            this.mnuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFilter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picErr)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(196, 580);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(176, 52);
            this.btnNext.TabIndex = 1;
            this.btnNext.Text = "Next Error";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrev
            // 
            this.btnPrev.Location = new System.Drawing.Point(14, 580);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(176, 52);
            this.btnPrev.TabIndex = 0;
            this.btnPrev.Text = "Prev Error";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // lblCurrObj
            // 
            this.lblCurrObj.AutoSize = true;
            this.lblCurrObj.Location = new System.Drawing.Point(378, 591);
            this.lblCurrObj.Name = "lblCurrObj";
            this.lblCurrObj.Size = new System.Drawing.Size(250, 32);
            this.lblCurrObj.TabIndex = 2;
            this.lblCurrObj.Text = "Current Error:    /    ";
            // 
            // lblFlagged
            // 
            this.lblFlagged.AutoSize = true;
            this.lblFlagged.Location = new System.Drawing.Point(12, 59);
            this.lblFlagged.Name = "lblFlagged";
            this.lblFlagged.Size = new System.Drawing.Size(188, 32);
            this.lblFlagged.TabIndex = 4;
            this.lblFlagged.Text = "Flagged Error";
            // 
            // lblFiltered
            // 
            this.lblFiltered.AutoSize = true;
            this.lblFiltered.Location = new System.Drawing.Point(658, 59);
            this.lblFiltered.Name = "lblFiltered";
            this.lblFiltered.Size = new System.Drawing.Size(183, 32);
            this.lblFiltered.TabIndex = 5;
            this.lblFiltered.Tag = "";
            this.lblFiltered.Text = "Filter Applied";
            // 
            // mnuStrip
            // 
            this.mnuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.aNNToolStripMenuItem,
            this.dataToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.mnuStrip.Location = new System.Drawing.Point(0, 0);
            this.mnuStrip.Name = "mnuStrip";
            this.mnuStrip.Size = new System.Drawing.Size(1315, 49);
            this.mnuStrip.TabIndex = 6;
            this.mnuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveImageSetToolStripMenuItem,
            this.saveCurrentImageToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(75, 45);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveImageSetToolStripMenuItem
            // 
            this.saveImageSetToolStripMenuItem.Name = "saveImageSetToolStripMenuItem";
            this.saveImageSetToolStripMenuItem.Size = new System.Drawing.Size(355, 46);
            this.saveImageSetToolStripMenuItem.Text = "Save Image Set";
            // 
            // saveCurrentImageToolStripMenuItem
            // 
            this.saveCurrentImageToolStripMenuItem.Name = "saveCurrentImageToolStripMenuItem";
            this.saveCurrentImageToolStripMenuItem.Size = new System.Drawing.Size(355, 46);
            this.saveCurrentImageToolStripMenuItem.Text = "Save Current Image";
            this.saveCurrentImageToolStripMenuItem.Click += new System.EventHandler(this.saveCurrentImageToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(355, 46);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.processingStepsToolStripMenuItem,
            this.aNNTrainerToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(94, 45);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // processingStepsToolStripMenuItem
            // 
            this.processingStepsToolStripMenuItem.Name = "processingStepsToolStripMenuItem";
            this.processingStepsToolStripMenuItem.Size = new System.Drawing.Size(319, 46);
            this.processingStepsToolStripMenuItem.Text = "Processing Steps";
            this.processingStepsToolStripMenuItem.Click += new System.EventHandler(this.processingStepsToolStripMenuItem_Click);
            // 
            // aNNToolStripMenuItem
            // 
            this.aNNToolStripMenuItem.Name = "aNNToolStripMenuItem";
            this.aNNToolStripMenuItem.Size = new System.Drawing.Size(114, 45);
            this.aNNToolStripMenuItem.Text = "A.N.N.";
            // 
            // aNNTrainerToolStripMenuItem
            // 
            this.aNNTrainerToolStripMenuItem.Name = "aNNTrainerToolStripMenuItem";
            this.aNNTrainerToolStripMenuItem.Size = new System.Drawing.Size(319, 46);
            this.aNNTrainerToolStripMenuItem.Text = "ANN Trainer";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(92, 45);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // dataToolStripMenuItem
            // 
            this.dataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.replaceCurrentToolStripMenuItem,
            this.replaceDatasetToolStripMenuItem,
            this.toolStripMenuItem1,
            this.removeCurrentToolStripMenuItem,
            this.killDatasetToolStripMenuItem,
            this.toolStripMenuItem2,
            this.nameDatasetToolStripMenuItem,
            this.commitDatasetToolStripMenuItem});
            this.dataToolStripMenuItem.Name = "dataToolStripMenuItem";
            this.dataToolStripMenuItem.Size = new System.Drawing.Size(91, 45);
            this.dataToolStripMenuItem.Text = "Data";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(99, 45);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // replaceCurrentToolStripMenuItem
            // 
            this.replaceCurrentToolStripMenuItem.Name = "replaceCurrentToolStripMenuItem";
            this.replaceCurrentToolStripMenuItem.Size = new System.Drawing.Size(310, 46);
            this.replaceCurrentToolStripMenuItem.Text = "Replace Current";
            // 
            // replaceDatasetToolStripMenuItem
            // 
            this.replaceDatasetToolStripMenuItem.Name = "replaceDatasetToolStripMenuItem";
            this.replaceDatasetToolStripMenuItem.Size = new System.Drawing.Size(310, 46);
            this.replaceDatasetToolStripMenuItem.Text = "Replace Dataset";
            // 
            // commitDatasetToolStripMenuItem
            // 
            this.commitDatasetToolStripMenuItem.Name = "commitDatasetToolStripMenuItem";
            this.commitDatasetToolStripMenuItem.Size = new System.Drawing.Size(310, 46);
            this.commitDatasetToolStripMenuItem.Text = "Commit Dataset";
            // 
            // removeCurrentToolStripMenuItem
            // 
            this.removeCurrentToolStripMenuItem.Name = "removeCurrentToolStripMenuItem";
            this.removeCurrentToolStripMenuItem.Size = new System.Drawing.Size(310, 46);
            this.removeCurrentToolStripMenuItem.Text = "Remove Current";
            // 
            // killDatasetToolStripMenuItem
            // 
            this.killDatasetToolStripMenuItem.Name = "killDatasetToolStripMenuItem";
            this.killDatasetToolStripMenuItem.Size = new System.Drawing.Size(310, 46);
            this.killDatasetToolStripMenuItem.Text = "Kill Dataset";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(307, 6);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(307, 6);
            // 
            // nameDatasetToolStripMenuItem
            // 
            this.nameDatasetToolStripMenuItem.Name = "nameDatasetToolStripMenuItem";
            this.nameDatasetToolStripMenuItem.Size = new System.Drawing.Size(310, 46);
            this.nameDatasetToolStripMenuItem.Text = "Name Dataset";
            // 
            // picFilter
            // 
            this.picFilter.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picFilter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picFilter.Location = new System.Drawing.Point(658, 94);
            this.picFilter.Name = "picFilter";
            this.picFilter.Size = new System.Drawing.Size(640, 480);
            this.picFilter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picFilter.TabIndex = 3;
            this.picFilter.TabStop = false;
            // 
            // picErr
            // 
            this.picErr.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picErr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picErr.Location = new System.Drawing.Point(12, 94);
            this.picErr.Name = "picErr";
            this.picErr.Size = new System.Drawing.Size(640, 480);
            this.picErr.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picErr.TabIndex = 0;
            this.picErr.TabStop = false;
            // 
            // _3DPQA_ErrorAnalyzer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1315, 650);
            this.Controls.Add(this.lblFiltered);
            this.Controls.Add(this.lblFlagged);
            this.Controls.Add(this.picFilter);
            this.Controls.Add(this.lblCurrObj);
            this.Controls.Add(this.btnPrev);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.picErr);
            this.Controls.Add(this.mnuStrip);
            this.MainMenuStrip = this.mnuStrip;
            this.Name = "_3DPQA_ErrorAnalyzer";
            this.Text = "Error Analysis";
            this.Load += new System.EventHandler(this._3DPQA_ErrorAnalyzer_Load);
            this.mnuStrip.ResumeLayout(false);
            this.mnuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFilter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picErr)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picErr;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Label lblCurrObj;
        private System.Windows.Forms.PictureBox picFilter;
        private System.Windows.Forms.Label lblFlagged;
        private System.Windows.Forms.Label lblFiltered;
        private System.Windows.Forms.MenuStrip mnuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveImageSetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveCurrentImageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem processingStepsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aNNTrainerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aNNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem replaceCurrentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem replaceDatasetToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem removeCurrentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem killDatasetToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem nameDatasetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem commitDatasetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
    }
}