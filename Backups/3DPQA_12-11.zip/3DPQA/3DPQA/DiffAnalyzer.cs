﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
// user imports
using System.IO;
using System.Drawing.Imaging;

namespace _3DPQA
{
    public partial class DiffAnalyzer : Form
    {
        String savePath = "";
        String exclusionFilePath = "";

        int likenessThreshold = 160;
        int internalThreshold = 5;
        int blobMinWidth = 10;
        int blobMinHeight = 10;
        int blobMinArea = 10;

        int ExcludeXPos = 0;
        int ExcludeYPos = 0;
        int ExcludeXDist = 0;
        int ExcludeYDist = 0;

        List<Bitmap> inputImages = new List<Bitmap>();
        ImageBlobCounter blobProcess = null;
        //SizeBasedClassification classify1 = new SizeBasedClassification();
        AnomalyEvaluator anomEval = null;
        public DiffAnalyzer()
        {
            InitializeComponent();
        }

        private void DiffAnalyzer_Load(object sender, EventArgs e)
        {
            inputImages.Add(Properties.Resources.bmp2);
            inputImages.Add(Properties.Resources.bmp1);
            inputImages.Add(Properties.Resources.bmp3);
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // debug: commented out b&w sorter slection, commented out checker, commented out toString for output, commented out if structure for color

            
            //*TO-DO* make type of processing variable dependent on what inputs are avaliable

#region Image_Processor
            if (radColor.Checked)
            {
                //ColorBlobCounter blobProcess;
                Color max = new Color();
                Color min = new Color();
                List<Color> backGroundThresh = new List<Color> { max, min };
                for (int i = 0; i < 2; i++)
                {
                    ColorDialog MyDialog = new ColorDialog();
                    MyDialog.AllowFullOpen = true;
                    MyDialog.Color = this.ForeColor;
                    // Update the text box color if the user clicks OK 
                    if (MyDialog.ShowDialog() == DialogResult.OK)
                        backGroundThresh[i] = MyDialog.Color;
                }

                if (chkCustomExZone.Checked == true)
                {
                    //blobProcess = new ColorBlobCounter(160, 5, exclusionFilePath, inputImages);
                }
                else
                {
                    blobProcess = new ColorBlobCounter(backGroundThresh, inputImages);
                }
            } else if (radMono.Checked == true)
                {
                    //ImageBlobCounter blobProcess;
                    if (chkCustomExZone.Checked == true)
                    {
                        blobProcess = new MonoBlobCounter(likenessThreshold, 5, exclusionFilePath, inputImages);
                    }
                    else
                    {
                        blobProcess = new MonoBlobCounter(likenessThreshold, 5, inputImages);
                    }
                }
#endregion

                // Display Outputs
                picSub.Image = blobProcess.getProcessingImages().ElementAt(0);      // subject image
                picBG.Image = blobProcess.getProcessingImages().ElementAt(1);       // background noise
                picComExp.Image = blobProcess.getProcessingImages().ElementAt(2);   // computer expected
                pictureBox4.Image = blobProcess.getProcessingImages().ElementAt(3); // derived diff
                pictureBox5.Image = blobProcess.getProcessingImages().ElementAt(4); // derived diff skew correction
                pictureBox6.Image = blobProcess.getProcessingImages().ElementAt(5); // bound image

#region Error_Flagging
                // attempt basic error flagging
                List<String> errorFlags = new List<String>();
                /*
                if (blobProcess.getBlobImage() != null)
                    {
                        Size tempSize = new Size(45, 45);
                        errorFlags = classify1.flagObvious(blobProcess.getImageBlob(), tempSize, 0.01); 
                    }
                */
                // send error package to processing
                //anomEval = new MonoLineFilter(blobProcess.getErrorImages(), LineFilterTypes.horz);
                anomEval = new HoughLine_Transformation(blobProcess.getErrorImages());

                // open up error processing form
                _3DPQA_ErrorAnalyzer formErrAn = new _3DPQA_ErrorAnalyzer(anomEval);
                formErrAn.ShowDialog();

                //pictureBox6.Image = anomEval.getClean().ElementAt(0);
#endregion

#region Save_Output
                try
                {
                    // Save .bmp output
                    blobProcess.getProcessingImages().ElementAt(3).Save(savePath + "\\Der-Diff_" + DateTime.Now.ToString("yyyyMMdd_hhmmss") + ".bmp", ImageFormat.Bmp);
                    blobProcess.getProcessingImages().ElementAt(4).Save(savePath + "\\DerDiff-Skew_" + DateTime.Now.ToString("yyyyMMdd_hhmmss") + ".bmp", ImageFormat.Bmp);
                    blobProcess.getProcessingImages().ElementAt(5).Save(savePath + "\\Bound_" + DateTime.Now.ToString("yyyyMMdd_hhmmss") + ".bmp", ImageFormat.Bmp);

                    // Save .txt output
                    System.IO.File.WriteAllText(savePath + "\\ObjectInfo_" + DateTime.Now.ToString("yyyyMMdd_hhmmss") + ".txt", blobProcess.toString());
                    String temp = "";
                    for (int i = 0; i < errorFlags.Count; i++)
                    {
                        temp = temp + errorFlags[i].ToString() + System.Environment.NewLine;
                    }
                    System.IO.File.WriteAllText(savePath + "\\Stop_info" + DateTime.Now.ToString("yyyyMMdd_hhmmss") + ".txt", temp);

                }
                catch (DirectoryNotFoundException ex)
                {
                    Console.WriteLine(ex.Message);
                    MessageBox.Show("Save Directory Not Found");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    if (savePath != "")
                    MessageBox.Show("Error Saving Processing Steps Files");
                }

            }
#endregion

#region Utility
        public int intTxtInput(string Input, int minVal, int maxVal)// limits txtbox inputs to a min and max
        {
            try
            {
                int m = Int32.Parse(Input);
                if (m >= minVal && m <= maxVal)
                    return m;
                else
                {
                    MessageBox.Show("Enter a Integer value between " + minVal + " and " + maxVal, "Input Error");
                    return 0;
                }
            }
            catch (FormatException er)
            {
                Console.WriteLine(er.Message);
                MessageBox.Show("Unrecognized Number Format", "Input Error");
                return 0;
            }
        }

        public int intTxtInput(string Input, int minVal)// limits txtbox inputs to a minimum and up
        {
            try
            {
                int m = Int32.Parse(Input);
                if (m >= 0)
                    return m;
                else MessageBox.Show("Enter a Integer value greater than " + minVal, "Input Error");
                return 0;
            }
            catch (FormatException er)
            {
                Console.WriteLine(er.Message);
                MessageBox.Show("Unrecognized Number Format", "Input Error");
                return 0;
            }
        } 

        private void checkError()
        {

        }

        private void output()
        {

        }
#endregion

        #region Form_Objects

        private void btnSaveDir_Click_1(object sender, EventArgs e)
        {
            string dummyFileName = "Save Here";

            SaveFileDialog sf = new SaveFileDialog();
            //dummy name to the save dialog
            sf.FileName = dummyFileName;

            if (sf.ShowDialog() == DialogResult.OK)
            {
                //save folder
                savePath = Path.GetDirectoryName(sf.FileName);
                btnSaveDir.Text = savePath;
            }

        }

        private void btnSubject_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "Open Image";
                dlg.Filter = "bmp files (*.bmp)|*.bmp";

                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    Bitmap temp = new Bitmap(dlg.FileName);
                    inputImages[0] = temp;
                    picSub.Image = temp;
                }
            }
        }

        private void btnBackGround_Click(object sender, EventArgs e)
        {
            // Wrap the creation of the OpenFileDialog instance in a using statement,
            // rather than manually calling the Dispose method to ensure proper disposal
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "Open Image";
                dlg.Filter = "bmp files (*.bmp)|*.bmp";

                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    Bitmap temp = new Bitmap(dlg.FileName);
                    inputImages[1] = temp;
                    picBG.Image = temp;
                }
            }
        }

        private void btnComExpected_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "Open Image";
                dlg.Filter = "bmp files (*.bmp)|*.bmp";

                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    Bitmap temp  = new Bitmap(dlg.FileName);
                    inputImages[2] = temp;
                    picComExp.Image = temp;
                }
            }
        }

        private void btnLoadExZones_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "Open Image";
                dlg.Filter = "txt files (*.txt)|*.txt";

                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    exclusionFilePath = dlg.FileName;
                }
            }
        }

        private void chkCustomExZone_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCustomExZone.Checked == true)
            {
                txtExcludeX.Enabled = true;
                txtExcludeY.Enabled = true;
                txtExcludeXDist.Enabled = true;
                txtExcludeYDist.Enabled = true;
                btnLoadExZones.Enabled = true;
                lblExcludeX.Enabled = true;
                lblExcludeY.Enabled = true;
                lblExcludeXDist.Enabled = true;
                lblExcludeYDist.Enabled = true;
            }
            else
            {
                txtExcludeX.Enabled = false;
                txtExcludeY.Enabled = false;
                txtExcludeXDist.Enabled = false;
                txtExcludeYDist.Enabled = false;
                btnLoadExZones.Enabled = false;
                lblExcludeX.Enabled = false;
                lblExcludeY.Enabled = false;
                lblExcludeXDist.Enabled = false;
                lblExcludeYDist.Enabled = false;
            }
        } 
        
        private void txtThres_TextChanged(object sender, EventArgs e)
        {
            TextBox txtThres_TextChanged = (TextBox)sender;
            string inputString = txtThres_TextChanged.Text;
            likenessThreshold = intTxtInput(inputString, 0, 255);
        }

        private void txtIdealImgThresh_TextChanged(object sender, EventArgs e)
        {
            TextBox txtInThres_TextChanged = (TextBox)sender;
            string inputString = txtInThres_TextChanged.Text;
            internalThreshold = intTxtInput(inputString, 0, 255);
        }

        private void txtMinWid_TextChanged(object sender, EventArgs e)
        {
            TextBox txtBlobMinW_TextChanged = (TextBox)sender;
            string inputString = txtBlobMinW_TextChanged.Text;
            blobMinWidth = intTxtInput(inputString, 0);
        }

        private void txtMinHei_TextChanged(object sender, EventArgs e)
        {
            TextBox txtBlobMinH_TextChanged = (TextBox)sender;
            string inputString = txtBlobMinH_TextChanged.Text;
            blobMinHeight = intTxtInput(inputString, 0);
        }

        private void txtExcludeX_TextChanged(object sender, EventArgs e)
        {
            TextBox txtExX_TextChanged = (TextBox)sender;
            string inputString = txtExX_TextChanged.Text;
            ExcludeXPos = intTxtInput(inputString, 0);
        }

        private void txtExcludeY_TextChanged(object sender, EventArgs e)
        {
            TextBox txtExY_TextChanged = (TextBox)sender;
            string inputString = txtExY_TextChanged.Text;
            ExcludeYPos = intTxtInput(inputString, 0);
        }

        private void txtExcludeXDist_TextChanged(object sender, EventArgs e)
        {
            TextBox txtExXD_TextChanged = (TextBox)sender;
            string inputString = txtExXD_TextChanged.Text;
            ExcludeXDist = intTxtInput(inputString, 1);
        }

        private void txtExcludeYDist_TextChanged(object sender, EventArgs e)
        {
            TextBox txtExYD_TextChanged = (TextBox)sender;
            string inputString = txtExYD_TextChanged.Text;
            ExcludeYDist = intTxtInput(inputString, 1);
        }

#endregion

    }
}
