﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// user imports
using System.IO;
using System.Drawing;


namespace _3DPQA
{
    class ImageIntake
    {
        protected Bitmap SubjectImage = null;
        protected Bitmap BackGround = null;
        protected Bitmap ComputerExpected = null;
        protected Bitmap DerivedDifferences = null;
        protected Bitmap DerivedDifferencesSkew = null;
        protected Bitmap BoundedImage = null;
        protected List<Bitmap> IsolatedError = new List<Bitmap>();

#region Constructors

        public ImageIntake() //default image constructor
        {
            this.SubjectImage = Properties.Resources.bmp2;
            this.BackGround = Properties.Resources.bmp1;
            this.ComputerExpected = Properties.Resources.bmp3;
        }

        public ImageIntake(List<Bitmap> inBitmap)
        {
            this.SubjectImage = inBitmap.ElementAt(0);
            this.BackGround = inBitmap.ElementAt(1);
            this.ComputerExpected = inBitmap.ElementAt(2);
        }

#endregion

        public void loadImages(List<Bitmap> inBitmap)
        {
            this.SubjectImage = inBitmap.ElementAt(0);
            this.BackGround = inBitmap.ElementAt(1);
            this.ComputerExpected = inBitmap.ElementAt(2);
        }

        public List<Bitmap> getProcessingImages()
        {
            List<Bitmap> temp = new List<Bitmap>();
            temp.Add(SubjectImage);
            temp.Add(BackGround);
            temp.Add(ComputerExpected);
            temp.Add(DerivedDifferences);
            temp.Add(DerivedDifferencesSkew);
            temp.Add(BoundedImage);
            return temp;
        }

        public List<Bitmap> getErrorImages()
        {
            return IsolatedError;
        }
    }
}
